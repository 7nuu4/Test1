--[[
	xNUU7 HUB · NotificationManager
	Pila de notificaciones: arriba a la derecha en PC/tablet, arriba al centro en teléfono.
	  - Estilos: Info, Success, Warning, Error (icono y color propios; todo sale del tema).
	  - Aparece con fundido + desplazamiento; al cerrar colapsa su altura y se destruye.
	  - Un toque/clic sobre la tarjeta la cierra (no depende de hover).
	  - Duration = 0 la mantiene hasta que se cierre.
	  - Cada notificación tiene su propio ámbito de limpieza: al terminar no queda nada vivo.

	Recibe el "runtime" ya construido por el núcleo:
	  { Gui, Cleanup, Theme, Icons, Animation, Responsive }
]]

local Util = require(script.Parent.Util)
local ConnectionManager = require(script.Parent.ConnectionManager)
local ThemeManager = require(script.Parent.ThemeManager)

local Notifications = {}
Notifications.__index = Notifications

local STYLES = {
	Info = { Icon = "info", Token = "Accent" },
	Success = { Icon = "check", Token = "Success" },
	Warning = { Icon = "alert", Token = "Warning" },
	Error = { Icon = "x", Token = "Danger" },
}

local MAX_WIDTH = 340
local ICON_SIZE = 22
local ICON_GAP = 10

function Notifications.new(runtime)
	local self = setmetatable({}, Notifications)
	self._runtime = runtime
	self._scope = runtime.Cleanup:Child()
	self._active = {}
	self._order = 0
	self.MaxVisible = 5

	self._list = Util.New("UIListLayout", {
		Padding = UDim.new(0, 8),
		SortOrder = Enum.SortOrder.LayoutOrder,
		HorizontalAlignment = Enum.HorizontalAlignment.Center,
	})
	self._holder = Util.New("Frame", {
		Name = "Notifications",
		BackgroundTransparency = 1,
		AutomaticSize = Enum.AutomaticSize.Y,
		Size = UDim2.fromOffset(MAX_WIDTH, 0),
		Parent = runtime.Gui,
	}, { self._list })
	self._scope:Add(self._holder)
	self._scope:Add(runtime.Responsive:OnChanged(function()
		self:_layout()
	end))
	self:_layout()
	return self
end

function Notifications:_layout()
	local responsive = self._runtime.Responsive
	local viewport = responsive:GetViewportSize()
	local width = math.clamp(viewport.X - 24, 200, MAX_WIDTH)
	self._holder.Size = UDim2.fromOffset(width, 0)
	if responsive:GetDevice() == "Phone" then
		self._holder.AnchorPoint = Vector2.new(0.5, 0)
		self._holder.Position = UDim2.new(0.5, 0, 0, 12)
		self._list.HorizontalAlignment = Enum.HorizontalAlignment.Center
	else
		self._holder.AnchorPoint = Vector2.new(1, 0)
		self._holder.Position = UDim2.new(1, -16, 0, 16)
		self._list.HorizontalAlignment = Enum.HorizontalAlignment.Right
	end
end

-- opts: Title, Content, Duration (s; 0 = fija), Type ("Info"|"Success"|"Warning"|"Error"),
--       Icon (nombre del catálogo de iconos).
-- Devuelve { Close = function, IsClosed = function }.
function Notifications:Notify(opts)
	opts = Util.Options("Notify", opts)
	local title = Util.Expect("Notify", "Title", opts.Title, "string", "Notificación")
	local content = Util.Expect("Notify", "Content", opts.Content, "string")
	local duration = Util.Expect("Notify", "Duration", opts.Duration, "number", 4)
	local styleName = Util.ExpectOneOf("Notify", "Type", opts.Type, STYLES, "Info")
	local style = STYLES[styleName]
	local iconName = Util.Expect("Notify", "Icon", opts.Icon, "string", style.Icon)
	if duration < 0 then
		Util.Error("Notify: 'Duration' no puede ser negativa", 2)
	end

	local rt = self._runtime
	local animation = rt.Animation
	local theme = rt.Theme
	local scope = self._scope:Child()
	local connections = ConnectionManager.new(scope)
	self._order = self._order + 1

	local wrapper = scope:Add(Util.New("Frame", {
		Name = "Notification",
		BackgroundTransparency = 1,
		AutomaticSize = Enum.AutomaticSize.Y,
		Size = UDim2.new(1, 0, 0, 0),
		LayoutOrder = self._order,
		Parent = self._holder,
	}))

	-- "shell" lleva el borde y se desplaza; "body" (CanvasGroup) hace el fundido del contenido.
	local stroke = Util.New("UIStroke", {
		Name = "Border",
		Thickness = 1,
		ApplyStrokeMode = Enum.ApplyStrokeMode.Border,
	})
	local shellCorner = Util.New("UICorner", { Name = "Corner" })
	local shell = Util.New("Frame", {
		Name = "Shell",
		BackgroundTransparency = 1,
		AutomaticSize = Enum.AutomaticSize.Y,
		Size = UDim2.new(1, 0, 0, 0),
		Position = UDim2.fromOffset(0, -14),
		Parent = wrapper,
	}, { shellCorner, stroke })

	local bodyCorner = Util.New("UICorner", { Name = "Corner" })
	local body = Util.New("CanvasGroup", {
		Name = "Body",
		BorderSizePixel = 0,
		AutomaticSize = Enum.AutomaticSize.Y,
		Size = UDim2.new(1, 0, 0, 0),
		GroupTransparency = 1,
		Active = true,
		Parent = shell,
	}, {
		bodyCorner,
		Util.New("UIListLayout", { SortOrder = Enum.SortOrder.LayoutOrder }),
	})

	local row = Util.New("Frame", {
		Name = "Row",
		BackgroundTransparency = 1,
		AutomaticSize = Enum.AutomaticSize.Y,
		Size = UDim2.new(1, 0, 0, 0),
		LayoutOrder = 1,
		Parent = body,
	}, {
		Util.New("UIPadding", {
			PaddingTop = UDim.new(0, 12),
			PaddingBottom = UDim.new(0, 12),
			PaddingLeft = UDim.new(0, 14),
			PaddingRight = UDim.new(0, 14),
		}),
		Util.New("UIListLayout", {
			FillDirection = Enum.FillDirection.Horizontal,
			Padding = UDim.new(0, ICON_GAP),
			SortOrder = Enum.SortOrder.LayoutOrder,
			VerticalAlignment = Enum.VerticalAlignment.Top,
		}),
	})

	local iconSlot = Util.New("Frame", {
		Name = "IconSlot",
		BackgroundTransparency = 1,
		Size = UDim2.fromOffset(ICON_SIZE, ICON_SIZE),
		LayoutOrder = 1,
		Parent = row,
	})
	rt.Icons:Create(iconName, { Size = ICON_SIZE, Color = style.Token, Parent = iconSlot })

	local textColumn = Util.New("Frame", {
		Name = "Text",
		BackgroundTransparency = 1,
		AutomaticSize = Enum.AutomaticSize.Y,
		Size = UDim2.new(1, -(ICON_SIZE + ICON_GAP), 0, 0),
		LayoutOrder = 2,
		Parent = row,
	}, {
		Util.New("UIListLayout", {
			Padding = UDim.new(0, 2),
			SortOrder = Enum.SortOrder.LayoutOrder,
		}),
	})

	local titleLabel = Util.New("TextLabel", {
		Name = "Title",
		BackgroundTransparency = 1,
		AutomaticSize = Enum.AutomaticSize.Y,
		Size = UDim2.new(1, 0, 0, 0),
		Font = ThemeManager.Fonts.Bold,
		TextSize = 15,
		TextWrapped = true,
		TextXAlignment = Enum.TextXAlignment.Left,
		TextYAlignment = Enum.TextYAlignment.Top,
		Text = title,
		LayoutOrder = 1,
		Parent = textColumn,
	})
	theme:Bind(titleLabel, { TextColor3 = "Text" }, scope)

	if content and content ~= "" then
		local contentLabel = Util.New("TextLabel", {
			Name = "Content",
			BackgroundTransparency = 1,
			AutomaticSize = Enum.AutomaticSize.Y,
			Size = UDim2.new(1, 0, 0, 0),
			Font = ThemeManager.Fonts.Regular,
			TextSize = 13,
			TextWrapped = true,
			TextXAlignment = Enum.TextXAlignment.Left,
			TextYAlignment = Enum.TextYAlignment.Top,
			Text = content,
			LayoutOrder = 2,
			Parent = textColumn,
		})
		theme:Bind(contentLabel, { TextColor3 = "TextSecondary" }, scope)
	end

	local progressFill = nil
	if duration > 0 then
		local track = Util.New("Frame", {
			Name = "Progress",
			BackgroundTransparency = 1,
			Size = UDim2.new(1, 0, 0, 3),
			LayoutOrder = 2,
			Parent = body,
		})
		progressFill = Util.New("Frame", {
			Name = "Fill",
			BorderSizePixel = 0,
			BackgroundTransparency = 0.35,
			Size = UDim2.fromScale(1, 1),
			Parent = track,
		})
		theme:Bind(progressFill, { BackgroundColor3 = style.Token }, scope)
	end

	local radius = ThemeManager.Radius("CornerRadius")
	theme:Bind(shellCorner, { CornerRadius = radius }, scope)
	theme:Bind(bodyCorner, { CornerRadius = radius }, scope)
	theme:Bind(stroke, { Color = "Border", Transparency = "BorderTransparency" }, scope)
	theme:Bind(body, { BackgroundColor3 = "Surface", BackgroundTransparency = "PanelTransparency" }, scope)

	-- Estado de partida de la entrada (el Bind anterior fijó los valores del tema).
	stroke.Transparency = 1

	local state = { Closed = false }

	local function collapse()
		if wrapper.Parent == nil then
			return
		end
		wrapper.ClipsDescendants = true
		wrapper.AutomaticSize = Enum.AutomaticSize.None
		wrapper.Size = UDim2.new(1, 0, 0, wrapper.AbsoluteSize.Y)
		animation:Tween(wrapper, { Size = UDim2.new(1, 0, 0, 0) }, {
			Duration = "Fast",
			OnComplete = function()
				scope:Destroy()
			end,
		})
	end

	local function close()
		if state.Closed then
			return
		end
		state.Closed = true
		for index, item in ipairs(self._active) do
			if item == state then
				table.remove(self._active, index)
				break
			end
		end
		animation:Tween(body, { GroupTransparency = 1 }, { Duration = "Fast" })
		animation:Tween(stroke, { Transparency = 1 }, { Duration = "Fast" })
		animation:Tween(shell, { Position = UDim2.fromOffset(0, -10) }, {
			Duration = "Fast",
			OnComplete = collapse,
		})
	end
	state.Close = close

	connections:Connect(body.InputBegan, function(input)
		if
			input.UserInputType == Enum.UserInputType.MouseButton1
			or input.UserInputType == Enum.UserInputType.Touch
		then
			close()
		end
	end, "cierre de notificación por toque")

	table.insert(self._active, state)

	animation:Tween(body, { GroupTransparency = 0 }, { Duration = "Normal" })
	animation:Tween(shell, { Position = UDim2.fromOffset(0, 0) }, { Duration = "Normal" })
	animation:Tween(stroke, { Transparency = theme:Get("BorderTransparency") }, { Duration = "Normal" })

	if duration > 0 then
		if progressFill then
			animation:Tween(progressFill, { Size = UDim2.fromScale(0, 1) }, {
				Duration = duration,
				Style = Enum.EasingStyle.Linear,
				Essential = true,
			})
		end
		scope:Add(task.delay(duration, close))
	end

	while #self._active > self.MaxVisible do
		self._active[1].Close()
	end

	return {
		Close = close,
		IsClosed = function()
			return state.Closed
		end,
	}
end

function Notifications:CloseAll()
	local snapshot = {}
	for _, state in ipairs(self._active) do
		table.insert(snapshot, state)
	end
	for _, state in ipairs(snapshot) do
		state.Close()
	end
end

function Notifications:Destroy()
	self._active = {}
	self._scope:Destroy()
end

return Notifications
