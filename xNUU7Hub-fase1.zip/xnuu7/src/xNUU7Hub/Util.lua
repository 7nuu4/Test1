--[[
	xNUU7 HUB · Util
	Utilidades compartidas: mensajes de registro, validación de opciones y fábrica de instancias.
	Sin dependencias. Ningún error se oculta: SafeCall siempre registra el fallo con traza.
]]

local Util = {}

local PREFIX = "[xNUU7Hub] "

local function join(...)
	local count = select("#", ...)
	local parts = {}
	for i = 1, count do
		parts[i] = tostring((select(i, ...)))
	end
	return table.concat(parts, " ")
end

function Util.Warn(...)
	warn(PREFIX .. join(...))
end

-- Lanza un error con el prefijo de la librería. level 1 = quien llama a Util.Error.
function Util.Error(message, level)
	error(PREFIX .. tostring(message), (level or 1) + 1)
end

-- Ejecuta callback protegido. Si falla, registra el error con su traza y devuelve false, err.
-- Si funciona, devuelve true seguido de los resultados.
function Util.SafeCall(label, callback, ...)
	local results = table.pack(xpcall(callback, function(err)
		return debug.traceback(tostring(err), 2)
	end, ...))
	if not results[1] then
		Util.Warn("error en " .. tostring(label) .. ":\n" .. tostring(results[2]))
		return false, results[2]
	end
	return true, table.unpack(results, 2, results.n)
end

-- Valida que opts sea nil o tabla. Devuelve siempre una tabla.
function Util.Options(apiName, opts)
	if opts == nil then
		return {}
	end
	if type(opts) ~= "table" then
		Util.Error(apiName .. ": se esperaba una tabla de opciones y se recibió " .. typeof(opts), 3)
	end
	return opts
end

-- Valida el tipo de un campo (typeof). Si es nil devuelve default.
function Util.Expect(apiName, field, value, expectedType, default)
	if value == nil then
		return default
	end
	if typeof(value) ~= expectedType then
		Util.Error(
			string.format("%s: '%s' debe ser %s (recibido %s)", apiName, field, expectedType, typeof(value)),
			3
		)
	end
	return value
end

-- Valida que value sea una clave de la tabla allowed. Si es nil devuelve default.
function Util.ExpectOneOf(apiName, field, value, allowed, default)
	if value == nil then
		return default
	end
	if allowed[value] == nil then
		local names = {}
		for key in pairs(allowed) do
			table.insert(names, tostring(key))
		end
		table.sort(names)
		Util.Error(
			string.format(
				"%s: '%s' inválido (%s). Valores permitidos: %s",
				apiName,
				field,
				tostring(value),
				table.concat(names, ", ")
			),
			3
		)
	end
	return value
end

-- Crea una instancia, asigna propiedades, añade hijos y, al final, el Parent.
function Util.New(className, props, children)
	local instance = Instance.new(className)
	local parent = nil
	for key, value in pairs(props or {}) do
		if key == "Parent" then
			parent = value
		else
			instance[key] = value
		end
	end
	for _, child in ipairs(children or {}) do
		child.Parent = instance
	end
	if parent then
		instance.Parent = parent
	end
	return instance
end

function Util.ShallowCopy(source)
	local copy = {}
	for key, value in pairs(source) do
		copy[key] = value
	end
	return copy
end

return Util
