--[[
	xNUU7 HUB · Core  (Fase 1 de 4: infraestructura + notificaciones)
	Interfaz de usuario para Roblox (cliente). Sin dependencias de ejecutores ni de objetos
	remotos de otros juegos. Solo APIs oficiales de Roblox.

	API pública de esta fase:
	  xNUU7:Notify(opts)                 -> { Close, IsClosed }
	  xNUU7:SetTheme(nombre | tabla)     -> boolean
	  xNUU7:GetTheme()                   -> string
	  xNUU7:ListThemes()                 -> { string }
	  xNUU7:RegisterTheme(nombre, tabla)
	  xNUU7:CreateIcon(nombre, opts)     -> Icon { Instance, SetColor, SetSize, Destroy }
	  xNUU7:RegisterIcon(nombre, def) / RegisterAsset / RegisterGlyph
	  xNUU7:HasIcon(nombre) / ListIcons()
	  xNUU7:BindTheme(instancia, {Propiedad = "Token"}, scope?) -> función para desenlazar
	  xNUU7:Configure({ Animations, AnimationSpeed, ThemeTransition, Parent })
	  xNUU7:Destroy()

	Las ventanas, pestañas y componentes llegan en las fases 2-4 (ver README).
	Los métodos que empiezan por "_" son internos y los usarán esas fases.
]]

local Players = game:GetService("Players")

local Util = require(script.Util)
local Cleanup = require(script.CleanupManager)
local Animation = require(script.AnimationManager)
local Theme = require(script.ThemeManager)
local Icons = require(script.IconManager)
local Responsive = require(script.ResponsiveManager)
local Notifications = require(script.NotificationManager)

local Library = {
	Version = "0.1.0",
	Phase = 1,
}

local settings = {
	Animations = true,
	AnimationSpeed = 1,
	ThemeTransition = 0.25,
	Parent = nil,
}

local runtime = nil

local function applySettings(rt)
	rt.Animation:Configure({ Enabled = settings.Animations, Speed = settings.AnimationSpeed })
	rt.Theme:SetTransition(settings.ThemeTransition)
end

local function getRuntime()
	if runtime then
		return runtime
	end

	local parent = settings.Parent
	if not parent then
		local player = Players.LocalPlayer
		if not player then
			Util.Error("xNUU7Hub solo puede usarse en el cliente (LocalPlayer no disponible)", 3)
		end
		parent = player:FindFirstChildOfClass("PlayerGui") or player:WaitForChild("PlayerGui", 10)
		if not parent then
			Util.Error("PlayerGui no disponible tras 10 s", 3)
		end
	end

	local cleanup = Cleanup.new()
	local ok, result = xpcall(function()
		local animation = Animation.new(cleanup)
		local theme = Theme.new(cleanup, animation)
		local icons = Icons.new(cleanup, theme)
		local responsive = Responsive.new(cleanup)

		local gui = cleanup:Add(Util.New("ScreenGui", {
			Name = "xNUU7Hub",
			ResetOnSpawn = false,
			ZIndexBehavior = Enum.ZIndexBehavior.Sibling,
			DisplayOrder = 1000,
			ScreenInsets = Enum.ScreenInsets.DeviceSafeInsets,
			Parent = parent,
		}))

		local rt = {
			Cleanup = cleanup,
			Animation = animation,
			Theme = theme,
			Icons = icons,
			Responsive = responsive,
			Gui = gui,
		}
		rt.Notifications = Notifications.new(rt)
		applySettings(rt)
		return rt
	end, function(err)
		return debug.traceback(tostring(err), 2)
	end)

	if not ok then
		cleanup:Destroy()
		Util.Error("no se pudo inicializar la librería:\n" .. tostring(result), 3)
	end

	runtime = result
	return result
end

-- Acceso interno para las fases siguientes y para las pruebas.
function Library:_GetRuntime()
	return getRuntime()
end

function Library:Configure(opts)
	opts = Util.Options("Configure", opts)
	local animations = Util.Expect("Configure", "Animations", opts.Animations, "boolean")
	local speed = Util.Expect("Configure", "AnimationSpeed", opts.AnimationSpeed, "number")
	local transition = Util.Expect("Configure", "ThemeTransition", opts.ThemeTransition, "number")
	local parent = Util.Expect("Configure", "Parent", opts.Parent, "Instance")

	if speed ~= nil and speed <= 0 then
		Util.Error("Configure: 'AnimationSpeed' debe ser mayor que 0", 2)
	end
	if transition ~= nil and transition < 0 then
		Util.Error("Configure: 'ThemeTransition' no puede ser negativo", 2)
	end

	if animations ~= nil then
		settings.Animations = animations
	end
	if speed ~= nil then
		settings.AnimationSpeed = speed
	end
	if transition ~= nil then
		settings.ThemeTransition = transition
	end
	if parent ~= nil then
		settings.Parent = parent
	end

	if runtime then
		applySettings(runtime)
		if parent ~= nil then
			runtime.Gui.Parent = parent
		end
	end
end

-- Notificaciones --------------------------------------------------------------

function Library:Notify(opts)
	return getRuntime().Notifications:Notify(opts)
end

-- Temas -----------------------------------------------------------------------

function Library:SetTheme(target)
	return getRuntime().Theme:SetTheme(target)
end

function Library:GetTheme()
	return getRuntime().Theme:GetName()
end

function Library:ListThemes()
	return getRuntime().Theme:List()
end

function Library:RegisterTheme(name, def)
	getRuntime().Theme:Register(name, def)
end

function Library:BindTheme(instance, mapping, scope)
	return getRuntime().Theme:Bind(instance, mapping, scope)
end

-- Iconos ----------------------------------------------------------------------

function Library:CreateIcon(name, opts)
	return getRuntime().Icons:Create(name, opts)
end

function Library:RegisterIcon(name, def)
	getRuntime().Icons:Register(name, def)
end

function Library:RegisterAsset(name, image, rectSize, rectOffset)
	getRuntime().Icons:RegisterAsset(name, image, rectSize, rectOffset)
end

function Library:RegisterGlyph(name, text)
	getRuntime().Icons:RegisterGlyph(name, text)
end

function Library:HasIcon(name)
	return getRuntime().Icons:Has(name)
end

function Library:ListIcons()
	return getRuntime().Icons:List()
end

-- Ciclo de vida ---------------------------------------------------------------

function Library:Destroy()
	if not runtime then
		return
	end
	local rt = runtime
	runtime = nil
	rt.Cleanup:Destroy()
end

-- Componentes previstos pero aún no implementados: error explícito en vez de un
-- "attempt to call a nil value" confuso. Desaparecerá al implementarse cada fase.
local PLANNED = {
	CreateWindow = 2,
	Tab = 2,
	Section = 3,
	Button = 3,
	Toggle = 3,
	Checkbox = 3,
	Slider = 3,
	Input = 3,
	Dropdown = 3,
	Keybind = 3,
	Colorpicker = 3,
	Paragraph = 3,
	Label = 3,
	Divider = 3,
	Code = 3,
	Dialog = 4,
	Search = 4,
}

setmetatable(Library, {
	__index = function(_, key)
		local phase = PLANNED[key]
		if phase then
			Util.Error(
				string.format("'%s' aún no está implementado (previsto en la Fase %d). Consulta el README.", key, phase),
				2
			)
		end
		return nil
	end,
})

return Library
