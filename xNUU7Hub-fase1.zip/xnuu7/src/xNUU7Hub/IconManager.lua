--[[
	xNUU7 HUB · IconManager
	Catálogo de iconos propio, sin ReplicatedStorage ajeno, sin HTTP y sin assets de terceros.

	Tipos de icono:
	  Draw  - dibujado con Frames (líneas redondeadas, anillos y puntos). Es el tipo de los
	          iconos integrados: obra original, no requiere ningún asset.
	  Asset - ImageLabel con un rbxassetid que TÚ aportas (RegisterAsset).
	  Glyph - texto/carácter Unicode (RegisterGlyph). El renderizado depende de la fuente.

	Los iconos Draw se construyen una vez por (nombre, grosor) y se clonan (caché).
	Un nombre inexistente produce el icono "fallback" y un único aviso por nombre.
]]

local Util = require(script.Parent.Util)

local Icons = {}
Icons.__index = Icons

local DEFAULT_SIZE = 20
local DEFAULT_THICKNESS = 0.1
local MAX_WARNED = 64

-- ---------------------------------------------------------------------------
-- Dibujo procedural (coordenadas normalizadas 0..1 sobre un cuadrado)
-- ---------------------------------------------------------------------------

local function buildTemplate(name, drawFn, thickness)
	local host = Util.New("Frame", {
		Name = "Icon_" .. name,
		BackgroundTransparency = 1,
		Size = UDim2.fromOffset(DEFAULT_SIZE, DEFAULT_SIZE),
	})
	host:SetAttribute("IconThickness", thickness)

	local ctx = {}

	function ctx.Line(x1, y1, x2, y2)
		local dx, dy = x2 - x1, y2 - y1
		local length = math.sqrt(dx * dx + dy * dy)
		local part = Util.New("Frame", {
			Name = "Line",
			AnchorPoint = Vector2.new(0.5, 0.5),
			BorderSizePixel = 0,
			Position = UDim2.fromScale((x1 + x2) / 2, (y1 + y2) / 2),
			Size = UDim2.fromScale(length, thickness),
			Rotation = math.deg(math.atan2(dy, dx)),
			Parent = host,
		}, {
			Util.New("UICorner", { CornerRadius = UDim.new(1, 0) }),
		})
		part:SetAttribute("IconFill", true)
	end

	function ctx.Poly(points, closed)
		for index = 1, #points - 1 do
			ctx.Line(points[index][1], points[index][2], points[index + 1][1], points[index + 1][2])
		end
		if closed and #points > 2 then
			local last, first = points[#points], points[1]
			ctx.Line(last[1], last[2], first[1], first[2])
		end
	end

	function ctx.Ring(cx, cy, diameter)
		local stroke = Util.New("UIStroke", {
			Name = "Stroke",
			ApplyStrokeMode = Enum.ApplyStrokeMode.Border,
			Thickness = 2,
		})
		stroke:SetAttribute("IconStroke", true)
		Util.New("Frame", {
			Name = "Ring",
			AnchorPoint = Vector2.new(0.5, 0.5),
			BackgroundTransparency = 1,
			BorderSizePixel = 0,
			Position = UDim2.fromScale(cx, cy),
			Size = UDim2.fromScale(diameter, diameter),
			Parent = host,
		}, {
			Util.New("UICorner", { CornerRadius = UDim.new(1, 0) }),
			stroke,
		})
	end

	function ctx.Dot(cx, cy, diameter)
		local part = Util.New("Frame", {
			Name = "Dot",
			AnchorPoint = Vector2.new(0.5, 0.5),
			BorderSizePixel = 0,
			Position = UDim2.fromScale(cx, cy),
			Size = UDim2.fromScale(diameter, diameter),
			Parent = host,
		}, {
			Util.New("UICorner", { CornerRadius = UDim.new(1, 0) }),
		})
		part:SetAttribute("IconFill", true)
	end

	drawFn(ctx)
	return host
end

local BUILTIN = {
	["x"] = function(c)
		c.Line(0.26, 0.26, 0.74, 0.74)
		c.Line(0.74, 0.26, 0.26, 0.74)
	end,
	["minus"] = function(c)
		c.Line(0.2, 0.5, 0.8, 0.5)
	end,
	["plus"] = function(c)
		c.Line(0.2, 0.5, 0.8, 0.5)
		c.Line(0.5, 0.2, 0.5, 0.8)
	end,
	["check"] = function(c)
		c.Poly({ { 0.2, 0.54 }, { 0.42, 0.74 }, { 0.8, 0.28 } })
	end,
	["chevron-down"] = function(c)
		c.Poly({ { 0.24, 0.38 }, { 0.5, 0.64 }, { 0.76, 0.38 } })
	end,
	["chevron-up"] = function(c)
		c.Poly({ { 0.24, 0.62 }, { 0.5, 0.36 }, { 0.76, 0.62 } })
	end,
	["chevron-left"] = function(c)
		c.Poly({ { 0.62, 0.24 }, { 0.36, 0.5 }, { 0.62, 0.76 } })
	end,
	["chevron-right"] = function(c)
		c.Poly({ { 0.38, 0.24 }, { 0.64, 0.5 }, { 0.38, 0.76 } })
	end,
	["menu"] = function(c)
		c.Line(0.2, 0.28, 0.8, 0.28)
		c.Line(0.2, 0.5, 0.8, 0.5)
		c.Line(0.2, 0.72, 0.8, 0.72)
	end,
	["search"] = function(c)
		c.Ring(0.43, 0.43, 0.5)
		c.Line(0.64, 0.64, 0.82, 0.82)
	end,
	["house"] = function(c)
		c.Poly({ { 0.14, 0.5 }, { 0.5, 0.16 }, { 0.86, 0.5 } })
		c.Poly({ { 0.24, 0.42 }, { 0.24, 0.84 }, { 0.76, 0.84 }, { 0.76, 0.42 } })
		c.Line(0.5, 0.84, 0.5, 0.62)
	end,
	-- "settings" se dibuja como un panel de deslizadores (no como un engranaje).
	["settings"] = function(c)
		c.Line(0.15, 0.28, 0.85, 0.28)
		c.Line(0.15, 0.5, 0.85, 0.5)
		c.Line(0.15, 0.72, 0.85, 0.72)
		c.Dot(0.66, 0.28, 0.22)
		c.Dot(0.36, 0.5, 0.22)
		c.Dot(0.62, 0.72, 0.22)
	end,
	["user"] = function(c)
		c.Ring(0.5, 0.32, 0.3)
		c.Poly({ { 0.2, 0.84 }, { 0.24, 0.7 }, { 0.5, 0.6 }, { 0.76, 0.7 }, { 0.8, 0.84 } })
	end,
	["shield"] = function(c)
		c.Poly({ { 0.5, 0.12 }, { 0.82, 0.24 }, { 0.8, 0.54 }, { 0.5, 0.88 }, { 0.2, 0.54 }, { 0.18, 0.24 } }, true)
	end,
	["zap"] = function(c)
		c.Poly({ { 0.58, 0.1 }, { 0.24, 0.56 }, { 0.48, 0.56 }, { 0.42, 0.9 }, { 0.76, 0.44 }, { 0.52, 0.44 } }, true)
	end,
	["code"] = function(c)
		c.Poly({ { 0.36, 0.28 }, { 0.14, 0.5 }, { 0.36, 0.72 } })
		c.Poly({ { 0.64, 0.28 }, { 0.86, 0.5 }, { 0.64, 0.72 } })
		c.Line(0.57, 0.22, 0.43, 0.78)
	end,
	["palette"] = function(c)
		c.Ring(0.5, 0.5, 0.76)
		c.Dot(0.34, 0.42, 0.1)
		c.Dot(0.5, 0.3, 0.1)
		c.Dot(0.68, 0.42, 0.1)
		c.Dot(0.64, 0.62, 0.1)
	end,
	["bell"] = function(c)
		c.Poly({ { 0.24, 0.7 }, { 0.28, 0.44 }, { 0.38, 0.26 }, { 0.5, 0.2 }, { 0.62, 0.26 }, { 0.72, 0.44 }, { 0.76, 0.7 } }, true)
		c.Line(0.42, 0.82, 0.58, 0.82)
	end,
	["info"] = function(c)
		c.Ring(0.5, 0.5, 0.76)
		c.Line(0.5, 0.46, 0.5, 0.68)
		c.Dot(0.5, 0.32, 0.09)
	end,
	["alert"] = function(c)
		c.Poly({ { 0.5, 0.16 }, { 0.86, 0.8 }, { 0.14, 0.8 } }, true)
		c.Line(0.5, 0.4, 0.5, 0.58)
		c.Dot(0.5, 0.69, 0.07)
	end,
	["fallback"] = function(c)
		c.Ring(0.5, 0.5, 0.76)
		c.Dot(0.5, 0.5, 0.18)
	end,
}

-- ---------------------------------------------------------------------------
-- Objeto Icon devuelto por Create
-- ---------------------------------------------------------------------------

local Icon = {}
Icon.__index = Icon

local function pixelSize(size)
	if type(size) == "number" then
		return size
	end
	if size.X.Offset > 0 then
		return size.X.Offset
	end
	return DEFAULT_SIZE
end

local function paint(holder, color)
	if holder:IsA("ImageLabel") then
		holder.ImageColor3 = color
	elseif holder:IsA("TextLabel") then
		holder.TextColor3 = color
	else
		for _, descendant in ipairs(holder:GetDescendants()) do
			if descendant:GetAttribute("IconFill") then
				descendant.BackgroundColor3 = color
			elseif descendant:GetAttribute("IconStroke") then
				descendant.Color = color
			end
		end
	end
end

-- size: número (píxeles, cuadrado) o UDim2.
function Icon:SetSize(size)
	if type(size) ~= "number" and typeof(size) ~= "UDim2" then
		Util.Error("Icon:SetSize requiere un número o un UDim2", 2)
	end
	local holder = self.Instance
	holder.Size = type(size) == "number" and UDim2.fromOffset(size, size) or size
	if holder:IsA("Frame") then
		local thickness = holder:GetAttribute("IconThickness") or DEFAULT_THICKNESS
		local strokePixels = math.max(1, math.floor(thickness * pixelSize(size) + 0.5))
		for _, descendant in ipairs(holder:GetDescendants()) do
			if descendant:GetAttribute("IconStroke") then
				descendant.Thickness = strokePixels
			end
		end
	end
end

-- color: Color3 fijo o nombre de token del tema (sigue los cambios de tema).
function Icon:SetColor(color)
	if self._stopObserving then
		self._stopObserving()
		self._stopObserving = nil
	end
	if typeof(color) == "Color3" then
		paint(self.Instance, color)
	elseif type(color) == "string" then
		local holder = self.Instance
		self._stopObserving = self._theme:Observe(function(theme)
			local value = theme[color]
			if value == nil then
				Util.Warn("Icon: token de color desconocido '" .. color .. "'")
				return
			end
			paint(holder, value)
		end)
	else
		Util.Error("Icon:SetColor requiere un Color3 o un nombre de token", 2)
	end
end

function Icon:Destroy()
	if self._stopObserving then
		self._stopObserving()
		self._stopObserving = nil
	end
	self.Instance:Destroy()
end

-- ---------------------------------------------------------------------------
-- Gestor
-- ---------------------------------------------------------------------------

local function normalize(name)
	if type(name) ~= "string" or name == "" then
		return nil
	end
	return string.lower(name)
end

function Icons.new(cleanup, theme)
	local self = setmetatable({}, Icons)
	self._theme = theme
	self._catalog = {}
	self._templates = {}
	self._warned = {}
	self._warnedCount = 0
	self._destroyed = false
	for name, drawFn in pairs(BUILTIN) do
		self._catalog[name] = { Kind = "Draw", Draw = drawFn }
	end
	cleanup:Add(self)
	return self
end

function Icons:_dropTemplates(key)
	local prefix = key .. ":"
	for cacheKey, template in pairs(self._templates) do
		if string.sub(cacheKey, 1, #prefix) == prefix then
			self._templates[cacheKey] = nil
			template:Destroy()
		end
	end
end

-- def: {Kind="Draw", Draw=function(ctx)} | {Kind="Asset", Image=..., RectSize=?, RectOffset=?}
--      | {Kind="Glyph", Text=...}
function Icons:Register(name, def)
	local key = normalize(name)
	if not key then
		Util.Error("Icons:Register: el nombre debe ser un string no vacío", 2)
	end
	if type(def) ~= "table" then
		Util.Error("Icons:Register: la definición debe ser una tabla", 2)
	end

	local entry = { Kind = def.Kind }
	if def.Kind == "Draw" then
		if type(def.Draw) ~= "function" then
			Util.Error("Icons:Register: Kind 'Draw' requiere la función Draw(ctx)", 2)
		end
		entry.Draw = def.Draw
	elseif def.Kind == "Asset" then
		local image = def.Image
		if type(image) == "number" then
			image = "rbxassetid://" .. tostring(image)
		end
		if type(image) ~= "string" or not string.match(image, "^rbxassetid://%d+$") then
			Util.Error("Icons:Register: Image debe ser un id numérico o 'rbxassetid://<id>'", 2)
		end
		entry.Image = image
		entry.RectSize = def.RectSize
		entry.RectOffset = def.RectOffset
		if (entry.RectSize ~= nil and typeof(entry.RectSize) ~= "Vector2")
			or (entry.RectOffset ~= nil and typeof(entry.RectOffset) ~= "Vector2")
		then
			Util.Error("Icons:Register: RectSize y RectOffset deben ser Vector2", 2)
		end
	elseif def.Kind == "Glyph" then
		if type(def.Text) ~= "string" or def.Text == "" then
			Util.Error("Icons:Register: Kind 'Glyph' requiere Text (string no vacío)", 2)
		end
		entry.Text = def.Text
	else
		Util.Error("Icons:Register: Kind debe ser 'Draw', 'Asset' o 'Glyph'", 2)
	end

	self._catalog[key] = entry
	self:_dropTemplates(key)
end

function Icons:RegisterAsset(name, image, rectSize, rectOffset)
	self:Register(name, { Kind = "Asset", Image = image, RectSize = rectSize, RectOffset = rectOffset })
end

function Icons:RegisterGlyph(name, text)
	self:Register(name, { Kind = "Glyph", Text = text })
end

function Icons:Has(name)
	local key = normalize(name)
	return key ~= nil and self._catalog[key] ~= nil
end

function Icons:List()
	local names = {}
	for name in pairs(self._catalog) do
		table.insert(names, name)
	end
	table.sort(names)
	return names
end

function Icons:_instantiate(key, entry, thickness)
	if entry.Kind == "Draw" then
		local cacheKey = key .. ":" .. tostring(thickness)
		local template = self._templates[cacheKey]
		if not template then
			local ok, built = Util.SafeCall("icono '" .. key .. "'", buildTemplate, key, entry.Draw, thickness)
			if not ok then
				built = buildTemplate("fallback", BUILTIN.fallback, thickness)
			end
			template = built
			self._templates[cacheKey] = template
		end
		return template:Clone()
	elseif entry.Kind == "Asset" then
		return Util.New("ImageLabel", {
			Name = "Icon_" .. key,
			BackgroundTransparency = 1,
			Image = entry.Image,
			ImageRectSize = entry.RectSize or Vector2.new(0, 0),
			ImageRectOffset = entry.RectOffset or Vector2.new(0, 0),
			ScaleType = Enum.ScaleType.Fit,
		})
	end
	return Util.New("TextLabel", {
		Name = "Icon_" .. key,
		BackgroundTransparency = 1,
		Text = entry.Text,
		TextScaled = true,
		Font = Enum.Font.GothamBold,
	})
end

-- opts: Size (número | UDim2, por defecto 20), Color (Color3 | token, por defecto "Text"),
--       Thickness (0.04–0.3, solo iconos Draw), Parent.
function Icons:Create(name, opts)
	if self._destroyed then
		Util.Error("IconManager ya fue destruido", 2)
	end
	opts = Util.Options("CreateIcon", opts)
	local size = opts.Size
	if size == nil then
		size = DEFAULT_SIZE
	elseif type(size) ~= "number" and typeof(size) ~= "UDim2" then
		Util.Error("CreateIcon: 'Size' debe ser número o UDim2", 2)
	end
	local color = opts.Color
	if color == nil then
		color = "Text"
	end
	local thickness = math.clamp(Util.Expect("CreateIcon", "Thickness", opts.Thickness, "number", DEFAULT_THICKNESS), 0.04, 0.3)

	local key = normalize(name)
	local entry = key and self._catalog[key]
	if not entry then
		local label = tostring(name)
		if not self._warned[label] and self._warnedCount < MAX_WARNED then
			self._warned[label] = true
			self._warnedCount = self._warnedCount + 1
			Util.Warn("icono inexistente '" .. label .. "'; se usa el icono de reserva")
		end
		key = "fallback"
		entry = self._catalog.fallback
	end

	local holder = self:_instantiate(key, entry, thickness)
	local icon = setmetatable({ Instance = holder, _theme = self._theme, _stopObserving = nil }, Icon)
	icon:SetSize(size)
	icon:SetColor(color)
	if opts.Parent then
		holder.Parent = opts.Parent
	end
	-- Si la instancia se destruye por fuera, el observador de tema se detiene solo.
	holder.Destroying:Connect(function()
		if icon._stopObserving then
			icon._stopObserving()
			icon._stopObserving = nil
		end
	end)
	return icon
end

function Icons:Destroy()
	self._destroyed = true
	for _, template in pairs(self._templates) do
		template:Destroy()
	end
	self._templates = {}
	self._catalog = {}
end

return Icons
