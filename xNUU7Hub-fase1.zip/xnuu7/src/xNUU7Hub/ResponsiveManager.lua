--[[
	xNUU7 HUB · ResponsiveManager
	Información de pantalla y utilidades para adaptar la interfaz:
	  - GetViewportSize / GetDevice ("Phone" | "Tablet" | "Desktop") / IsTouch
	  - Fit(ancho, alto, margen): limita un tamaño deseado a la pantalla disponible
	  - GetInsets: márgenes del sistema (barra superior de Roblox, etc.)
	  - OnChanged(callback): avisa al cambiar la resolución o sustituirse la cámara
	La clasificación de dispositivo es una heurística (lado corto de la pantalla + táctil),
	no una detección exacta de hardware.
]]

local Workspace = game:GetService("Workspace")
local UserInputService = game:GetService("UserInputService")
local GuiService = game:GetService("GuiService")

local Util = require(script.Parent.Util)
local ConnectionManager = require(script.Parent.ConnectionManager)

local Responsive = {}
Responsive.__index = Responsive

-- Tamaño mínimo recomendado (px) de un objetivo táctil.
Responsive.MinTouchTarget = 44

local FALLBACK_VIEWPORT = Vector2.new(1280, 720)
local PHONE_MAX_SHORT_SIDE = 600

function Responsive.new(cleanup)
	local self = setmetatable({}, Responsive)
	self._connections = ConnectionManager.new(cleanup)
	self._listeners = {}
	self._camera = nil
	cleanup:Add(self)

	self._connections:Connect(Workspace:GetPropertyChangedSignal("CurrentCamera"), function()
		self:_watchCamera()
		self:_notify()
	end, "cambio de cámara")
	self:_watchCamera()
	return self
end

function Responsive:_watchCamera()
	local camera = Workspace.CurrentCamera
	self._camera = camera
	if camera then
		self._connections:ConnectKeyed("viewport", camera:GetPropertyChangedSignal("ViewportSize"), function()
			self:_notify()
		end, "cambio de resolución")
	else
		self._connections:Disconnect("viewport")
	end
end

function Responsive:GetViewportSize()
	local camera = self._camera
	if camera and camera.ViewportSize.X > 0 and camera.ViewportSize.Y > 0 then
		return camera.ViewportSize
	end
	return FALLBACK_VIEWPORT
end

function Responsive:IsTouch()
	return UserInputService.TouchEnabled
end

function Responsive:GetDevice()
	local viewport = self:GetViewportSize()
	local shortSide = math.min(viewport.X, viewport.Y)
	if shortSide < PHONE_MAX_SHORT_SIDE then
		return "Phone"
	end
	if UserInputService.TouchEnabled and not UserInputService.KeyboardEnabled then
		return "Tablet"
	end
	return "Desktop"
end

-- Limita un tamaño deseado (px) al espacio disponible dejando 'margin' px por cada lado.
function Responsive:Fit(width, height, margin)
	if type(width) ~= "number" or type(height) ~= "number" then
		Util.Error("Responsive:Fit requiere ancho y alto numéricos", 2)
	end
	margin = margin or 12
	local viewport = self:GetViewportSize()
	return Vector2.new(
		math.max(math.min(width, viewport.X - margin * 2), 1),
		math.max(math.min(height, viewport.Y - margin * 2), 1)
	)
end

-- Márgenes reservados por el sistema: { TopLeft = Vector2, BottomRight = Vector2 }.
function Responsive:GetInsets()
	local topLeft, bottomRight = GuiService:GetGuiInset()
	return { TopLeft = topLeft, BottomRight = bottomRight }
end

function Responsive:_notify()
	local callbacks = {}
	for _, callback in pairs(self._listeners) do
		table.insert(callbacks, callback)
	end
	if #callbacks == 0 then
		return
	end
	local viewport = self:GetViewportSize()
	local device = self:GetDevice()
	for _, callback in ipairs(callbacks) do
		Util.SafeCall("listener de Responsive", callback, viewport, device)
	end
end

-- callback(viewportSize, device). Devuelve una función para dejar de escuchar.
function Responsive:OnChanged(callback)
	if type(callback) ~= "function" then
		Util.Error("Responsive:OnChanged requiere una función", 2)
	end
	local id = {}
	self._listeners[id] = callback
	return function()
		self._listeners[id] = nil
	end
end

function Responsive:Destroy()
	self._connections:Destroy()
	self._listeners = {}
	self._camera = nil
end

return Responsive
