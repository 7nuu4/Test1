--[[
	xNUU7 HUB · AnimationManager
	Envoltorio de TweenService:
	  - Un tween por propiedad; uno nuevo sobre la misma propiedad cancela el anterior.
	  - Duraciones con nombre (Instant/Fast/Normal/Slow) o en segundos.
	  - Se puede desactivar o acelerar globalmente (Configure). Con las animaciones
	    desactivadas los valores se asignan al instante y OnComplete se llama igualmente.
	  - Essential = true ignora Enabled/Speed (para temporizadores visuales que deben ser exactos).
	  - Destroy cancela todo lo que siga en marcha.
	OnComplete solo se invoca si la animación termina sin ser interrumpida.
]]

local TweenService = game:GetService("TweenService")

local Util = require(script.Parent.Util)

local Animation = {}
Animation.__index = Animation

Animation.Durations = {
	Instant = 0,
	Fast = 0.14,
	Normal = 0.24,
	Slow = 0.4,
}

local NOOP_HANDLE = {
	Cancel = function() end,
}

local function resolveDuration(value)
	if value == nil then
		return Animation.Durations.Normal
	end
	if type(value) == "number" then
		return math.max(value, 0)
	end
	local preset = Animation.Durations[value]
	if preset == nil then
		Util.Error("Animation: duración desconocida '" .. tostring(value) .. "'", 3)
	end
	return preset
end

local function cancelRecord(record)
	record.Connection:Disconnect()
	record.Tween:Cancel()
end

function Animation.new(cleanup)
	local self = setmetatable({}, Animation)
	self._enabled = true
	self._speed = 1
	self._destroyed = false
	self._active = setmetatable({}, { __mode = "k" })
	cleanup:Add(self)
	return self
end

function Animation:Configure(config)
	config = Util.Options("Animation:Configure", config)
	local enabled = Util.Expect("Animation:Configure", "Enabled", config.Enabled, "boolean")
	local speed = Util.Expect("Animation:Configure", "Speed", config.Speed, "number")
	if enabled ~= nil then
		self._enabled = enabled
	end
	if speed ~= nil then
		if speed <= 0 then
			Util.Error("Animation:Configure: 'Speed' debe ser mayor que 0", 2)
		end
		self._speed = speed
	end
end

function Animation:IsEnabled()
	return self._enabled
end

function Animation:_cancelProperty(instance, property)
	local records = self._active[instance]
	if not records then
		return
	end
	local record = records[property]
	if record then
		records[property] = nil
		cancelRecord(record)
	end
	if next(records) == nil then
		self._active[instance] = nil
	end
end

-- Cancela todos los tweens activos de una instancia.
function Animation:Cancel(instance)
	local records = self._active[instance]
	if not records then
		return
	end
	local properties = {}
	for property in pairs(records) do
		table.insert(properties, property)
	end
	for _, property in ipairs(properties) do
		self:_cancelProperty(instance, property)
	end
end

-- opts: Duration (número | "Instant" | "Fast" | "Normal" | "Slow"), Style, Direction,
--       Delay, OnComplete, Essential. Devuelve un handle con :Cancel().
function Animation:Tween(instance, props, opts)
	if self._destroyed then
		return NOOP_HANDLE
	end
	if typeof(instance) ~= "Instance" then
		Util.Error("Animation:Tween requiere una Instance (recibido " .. typeof(instance) .. ")", 2)
	end
	if type(props) ~= "table" then
		Util.Error("Animation:Tween requiere una tabla de propiedades", 2)
	end
	opts = opts or {}

	local essential = opts.Essential == true
	local duration = resolveDuration(opts.Duration)
	if not essential then
		duration = duration / self._speed
	end
	local onComplete = opts.OnComplete

	if (not essential and not self._enabled) or duration <= 0 then
		for property, value in pairs(props) do
			self:_cancelProperty(instance, property)
			instance[property] = value
		end
		if onComplete then
			task.defer(Util.SafeCall, "OnComplete de animación", onComplete)
		end
		return NOOP_HANDLE
	end

	local info = TweenInfo.new(
		duration,
		opts.Style or Enum.EasingStyle.Quint,
		opts.Direction or Enum.EasingDirection.Out,
		0,
		false,
		opts.Delay or 0
	)

	local pending = 0
	for _ in pairs(props) do
		pending = pending + 1
	end
	if pending == 0 then
		if onComplete then
			task.defer(Util.SafeCall, "OnComplete de animación", onComplete)
		end
		return NOOP_HANDLE
	end

	local cancelled = false
	local mine = {}

	for property, value in pairs(props) do
		self:_cancelProperty(instance, property)
		local records = self._active[instance]
		if not records then
			records = {}
			self._active[instance] = records
		end

		local tween = TweenService:Create(instance, info, { [property] = value })
		local record = { Tween = tween }
		record.Connection = tween.Completed:Connect(function(state)
			record.Connection:Disconnect()
			local current = self._active[instance]
			if current and current[property] == record then
				current[property] = nil
				if next(current) == nil then
					self._active[instance] = nil
				end
			end
			if state == Enum.PlaybackState.Completed and not cancelled then
				pending = pending - 1
				if pending == 0 and onComplete then
					Util.SafeCall("OnComplete de animación", onComplete)
				end
			end
		end)
		records[property] = record
		mine[property] = record
		tween:Play()
	end

	return {
		Cancel = function()
			cancelled = true
			for property, record in pairs(mine) do
				local current = self._active[instance]
				if current and current[property] == record then
					self:_cancelProperty(instance, property)
				end
			end
		end,
	}
end

function Animation:Destroy()
	if self._destroyed then
		return
	end
	self._destroyed = true
	for _, records in pairs(self._active) do
		for _, record in pairs(records) do
			cancelRecord(record)
		end
	end
	self._active = {}
end

return Animation
