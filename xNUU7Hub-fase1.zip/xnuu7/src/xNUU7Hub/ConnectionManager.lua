--[[
	xNUU7 HUB · ConnectionManager
	Conexiones a eventos con tres garantías:
	  1. Los errores del callback se registran con traza (nunca se ocultan).
	  2. Las conexiones con clave (ConnectKeyed) no se duplican: reemplazan a la anterior.
	  3. Todo se desconecta al destruir el gestor o el ámbito padre.
]]

local Util = require(script.Parent.Util)
local Cleanup = require(script.Parent.CleanupManager)

local Connections = {}
Connections.__index = Connections

function Connections.new(parentCleanup)
	local self = setmetatable({}, Connections)
	self._scope = parentCleanup and parentCleanup:Child() or Cleanup.new()
	self._live = {}
	self._keyed = {}
	return self
end

function Connections:Connect(signal, callback, label)
	if self._scope:IsDestroyed() then
		Util.Warn("Connect ignorado: el gestor ya fue destruido (" .. tostring(label or "sin etiqueta") .. ")")
		return nil
	end
	if typeof(signal) ~= "RBXScriptSignal" then
		Util.Error("Connections:Connect requiere un RBXScriptSignal (recibido " .. typeof(signal) .. ")", 2)
	end
	if type(callback) ~= "function" then
		Util.Error("Connections:Connect requiere una función como callback", 2)
	end
	local name = label or "callback de evento"
	local connection = signal:Connect(function(...)
		Util.SafeCall(name, callback, ...)
	end)
	self._live[connection] = true
	self._scope:Add(connection)
	return connection
end

-- Igual que Connect, pero solo puede existir una conexión por clave.
function Connections:ConnectKeyed(key, signal, callback, label)
	self:Disconnect(key)
	local connection = self:Connect(signal, callback, label)
	if connection then
		self._keyed[key] = connection
	end
	return connection
end

function Connections:Disconnect(key)
	local connection = self._keyed[key]
	if connection then
		self._keyed[key] = nil
		self._live[connection] = nil
		connection:Disconnect()
	end
end

-- Número de conexiones que siguen activas.
function Connections:Count()
	local count = 0
	for connection in pairs(self._live) do
		if connection.Connected then
			count = count + 1
		else
			self._live[connection] = nil
		end
	end
	return count
end

function Connections:Destroy()
	self._scope:Destroy()
	self._live = {}
	self._keyed = {}
end

return Connections
