--[[
	xNUU7 HUB · ThemeManager
	Todos los colores y propiedades visuales viven aquí, como "tokens".
	Los componentes NO guardan colores: se enlazan con Bind(instancia, {Propiedad = "Token"})
	y al cambiar de tema se actualizan con una transición, sin recrear nada.

	Temas integrados: Dark, Light, Midnight, OLED. Custom parte de Dark y se modifica con
	SetCustom / SetTheme({ ... }). Paleta original, inspirada en las guías de color de Apple.
]]

local Util = require(script.Parent.Util)

local Theme = {}
Theme.__index = Theme

Theme.Fonts = {
	Regular = Enum.Font.Gotham,
	Medium = Enum.Font.GothamMedium,
	Bold = Enum.Font.GothamBold,
	Mono = Enum.Font.RobotoMono,
}

local COLOR_TOKENS = {
	Background = true,
	Surface = true,
	SurfaceHover = true,
	SurfaceActive = true,
	Border = true,
	Text = true,
	TextSecondary = true,
	Accent = true,
	AccentText = true,
	Success = true,
	Warning = true,
	Danger = true,
	Shadow = true,
}

-- Valor mínimo y máximo permitidos por token numérico.
local NUMBER_TOKENS = {
	PanelTransparency = { 0, 1 },
	BorderTransparency = { 0, 1 },
	CornerRadius = { 0, 64 },
	ElementRadius = { 0, 64 },
}

local function rgb(r, g, b)
	return Color3.fromRGB(r, g, b)
end

local BUILTIN = {
	Dark = {
		Background = rgb(22, 22, 24),
		Surface = rgb(34, 34, 37),
		SurfaceHover = rgb(46, 46, 50),
		SurfaceActive = rgb(58, 58, 63),
		Border = rgb(84, 84, 88),
		Text = rgb(245, 245, 247),
		TextSecondary = rgb(152, 152, 157),
		Accent = rgb(10, 132, 255),
		AccentText = rgb(255, 255, 255),
		Success = rgb(48, 209, 88),
		Warning = rgb(255, 159, 10),
		Danger = rgb(255, 69, 58),
		Shadow = rgb(0, 0, 0),
		PanelTransparency = 0.04,
		BorderTransparency = 0.55,
		CornerRadius = 16,
		ElementRadius = 10,
	},
	Light = {
		Background = rgb(242, 242, 247),
		Surface = rgb(255, 255, 255),
		SurfaceHover = rgb(235, 235, 240),
		SurfaceActive = rgb(225, 225, 231),
		Border = rgb(198, 198, 203),
		Text = rgb(28, 28, 30),
		TextSecondary = rgb(110, 110, 115),
		Accent = rgb(0, 122, 255),
		AccentText = rgb(255, 255, 255),
		Success = rgb(52, 199, 89),
		Warning = rgb(255, 149, 0),
		Danger = rgb(255, 59, 48),
		Shadow = rgb(0, 0, 0),
		PanelTransparency = 0.02,
		BorderTransparency = 0.2,
		CornerRadius = 16,
		ElementRadius = 10,
	},
	Midnight = {
		Background = rgb(10, 12, 28),
		Surface = rgb(20, 24, 48),
		SurfaceHover = rgb(30, 36, 68),
		SurfaceActive = rgb(42, 50, 92),
		Border = rgb(70, 82, 140),
		Text = rgb(232, 236, 255),
		TextSecondary = rgb(140, 150, 195),
		Accent = rgb(94, 92, 230),
		AccentText = rgb(255, 255, 255),
		Success = rgb(50, 215, 160),
		Warning = rgb(255, 190, 60),
		Danger = rgb(255, 90, 110),
		Shadow = rgb(0, 0, 0),
		PanelTransparency = 0.04,
		BorderTransparency = 0.5,
		CornerRadius = 16,
		ElementRadius = 10,
	},
	OLED = {
		Background = rgb(0, 0, 0),
		Surface = rgb(10, 10, 12),
		SurfaceHover = rgb(22, 22, 26),
		SurfaceActive = rgb(34, 34, 40),
		Border = rgb(60, 60, 66),
		Text = rgb(255, 255, 255),
		TextSecondary = rgb(140, 140, 146),
		Accent = rgb(10, 132, 255),
		AccentText = rgb(255, 255, 255),
		Success = rgb(48, 209, 88),
		Warning = rgb(255, 159, 10),
		Danger = rgb(255, 69, 58),
		Shadow = rgb(0, 0, 0),
		PanelTransparency = 0,
		BorderTransparency = 0.6,
		CornerRadius = 16,
		ElementRadius = 10,
	},
}

-- Ayudantes para valores derivados del tema (se pasan en Bind como función).
function Theme.Radius(token)
	return function(theme)
		return UDim.new(0, theme[token])
	end
end

function Theme.Mix(tokenA, tokenB, alpha)
	return function(theme)
		return theme[tokenA]:Lerp(theme[tokenB], alpha)
	end
end

-- Mezcla def sobre base validando tipos y rangos. Los valores inválidos se ignoran con aviso.
local function sanitize(apiName, def, base)
	local result = Util.ShallowCopy(base)
	for key, value in pairs(def) do
		if COLOR_TOKENS[key] then
			if typeof(value) == "Color3" then
				result[key] = value
			else
				Util.Warn(apiName .. ": '" .. key .. "' debe ser Color3; se ignora")
			end
		elseif NUMBER_TOKENS[key] then
			if type(value) == "number" then
				local range = NUMBER_TOKENS[key]
				result[key] = math.clamp(value, range[1], range[2])
			else
				Util.Warn(apiName .. ": '" .. key .. "' debe ser número; se ignora")
			end
		else
			Util.Warn(apiName .. ": token desconocido '" .. tostring(key) .. "' ignorado")
		end
	end
	return result
end

local function resolve(theme, reference)
	if type(reference) == "function" then
		return reference(theme)
	end
	local value = theme[reference]
	if value == nil then
		Util.Warn("token de tema desconocido:", reference)
	end
	return value
end

function Theme.new(cleanup, animation)
	local self = setmetatable({}, Theme)
	self._themes = {}
	for name, def in pairs(BUILTIN) do
		self._themes[name] = def
	end
	self._themes.Custom = Util.ShallowCopy(BUILTIN.Dark)
	self._name = "Dark"
	self._current = self._themes.Dark
	self._binds = setmetatable({}, { __mode = "k" })
	self._observers = {}
	self._transition = 0.25
	self._animation = animation
	cleanup:Add(self)
	return self
end

function Theme:List()
	local names = {}
	for name in pairs(self._themes) do
		table.insert(names, name)
	end
	table.sort(names)
	return names
end

function Theme:Has(name)
	return self._themes[name] ~= nil
end

function Theme:GetName()
	return self._name
end

-- Valor de un token del tema activo (ya es el valor final, aunque la transición siga en curso).
function Theme:Get(token)
	return self._current[token]
end

function Theme:SetTransition(seconds)
	if type(seconds) ~= "number" or seconds < 0 then
		Util.Error("Theme:SetTransition requiere un número >= 0", 2)
	end
	self._transition = seconds
end

function Theme:Register(name, def)
	if type(name) ~= "string" or name == "" then
		Util.Error("Theme:Register: el nombre debe ser un string no vacío", 2)
	end
	if BUILTIN[name] then
		Util.Error("Theme:Register: '" .. name .. "' es un tema integrado y no se puede sobrescribir", 2)
	end
	if type(def) ~= "table" then
		Util.Error("Theme:Register: la definición debe ser una tabla de tokens", 2)
	end
	self._themes[name] = sanitize("Theme:Register", def, BUILTIN.Dark)
	if self._name == name then
		self:_apply(name)
	end
end

-- Modifica el tema Custom (acumulativo). Si Custom está activo se aplica en caliente.
function Theme:SetCustom(overrides)
	if type(overrides) ~= "table" then
		Util.Error("Theme:SetCustom requiere una tabla de tokens", 2)
	end
	self._themes.Custom = sanitize("Theme:SetCustom", overrides, self._themes.Custom)
	if self._name == "Custom" then
		self:_apply("Custom")
	end
end

-- Acepta el nombre de un tema o una tabla de tokens (se aplica como Custom).
-- Devuelve true si se aplicó; false (con aviso) si el nombre no existe.
function Theme:SetTheme(target)
	if type(target) == "table" then
		self._themes.Custom = sanitize("SetTheme", target, self._themes.Custom)
		self:_apply("Custom")
		return true
	end
	if type(target) ~= "string" then
		Util.Warn("SetTheme: se esperaba el nombre de un tema o una tabla de tokens")
		return false
	end
	if not self._themes[target] then
		Util.Warn("SetTheme: tema desconocido '" .. target .. "'. Disponibles: " .. table.concat(self:List(), ", "))
		return false
	end
	self:_apply(target)
	return true
end

function Theme:_applyEntry(instance, entry, animate)
	for property, reference in pairs(entry) do
		local value = resolve(self._current, reference)
		if value ~= nil then
			if animate then
				self._animation:Tween(instance, { [property] = value }, { Duration = self._transition })
			else
				instance[property] = value
			end
		end
	end
end

function Theme:_apply(name)
	self._name = name
	self._current = self._themes[name]

	local targets = {}
	for instance, entry in pairs(self._binds) do
		table.insert(targets, { instance, entry })
	end
	for _, target in ipairs(targets) do
		Util.SafeCall("aplicar tema", self._applyEntry, self, target[1], target[2], true)
	end

	local callbacks = {}
	for _, callback in pairs(self._observers) do
		table.insert(callbacks, callback)
	end
	for _, callback in ipairs(callbacks) do
		Util.SafeCall("observador de tema", callback, self._current, name)
	end
end

-- Enlaza propiedades de una instancia con tokens: Bind(frame, {BackgroundColor3 = "Surface"}).
-- El valor puede ser un token (string) o una función(theme) -> valor.
-- Aplica el tema actual de inmediato. Devuelve una función para desenlazar.
function Theme:Bind(instance, mapping, scope)
	if typeof(instance) ~= "Instance" then
		Util.Error("Theme:Bind requiere una Instance (recibido " .. typeof(instance) .. ")", 2)
	end
	if type(mapping) ~= "table" then
		Util.Error("Theme:Bind requiere una tabla {Propiedad = Token}", 2)
	end
	local entry = self._binds[instance]
	if not entry then
		entry = {}
		self._binds[instance] = entry
	end
	local keys = {}
	for property, reference in pairs(mapping) do
		entry[property] = reference
		table.insert(keys, property)
	end
	self:_applyEntry(instance, mapping, false)

	local function unbind()
		local current = self._binds[instance]
		if not current then
			return
		end
		for _, property in ipairs(keys) do
			current[property] = nil
		end
		if next(current) == nil then
			self._binds[instance] = nil
		end
	end
	if scope then
		scope:Add(unbind)
	end
	return unbind
end

-- Llama a callback(theme, nombre) ahora y en cada cambio. Devuelve una función para parar.
function Theme:Observe(callback, scope)
	if type(callback) ~= "function" then
		Util.Error("Theme:Observe requiere una función", 2)
	end
	local id = {}
	self._observers[id] = callback
	local function stop()
		self._observers[id] = nil
	end
	if scope then
		scope:Add(stop)
	end
	Util.SafeCall("observador de tema", callback, self._current, self._name)
	return stop
end

function Theme:Destroy()
	self._binds = {}
	self._observers = {}
end

return Theme
