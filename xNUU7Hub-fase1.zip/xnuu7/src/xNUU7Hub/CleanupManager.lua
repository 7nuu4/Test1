--[[
	xNUU7 HUB · CleanupManager
	Ámbito de limpieza ("scope"). Todo lo que se crea dentro de un ámbito se libera al destruirlo.
	Admite: RBXScriptConnection, Instance, function, thread (suspendido) y tablas con
	Destroy / Disconnect / Cancel. Los ámbitos hijos se desregistran del padre al destruirse.
]]

local Util = require(script.Parent.Util)

local Cleanup = {}
Cleanup.__index = Cleanup

local function dispose(item)
	local kind = typeof(item)
	if kind == "RBXScriptConnection" then
		item:Disconnect()
	elseif kind == "Instance" then
		item:Destroy()
	elseif kind == "function" then
		item()
	elseif kind == "thread" then
		-- Solo se cancelan hilos suspendidos (p. ej. task.delay pendiente).
		if coroutine.status(item) == "suspended" then
			task.cancel(item)
		end
	elseif kind == "table" then
		if type(item.Destroy) == "function" then
			item:Destroy()
		elseif type(item.Disconnect) == "function" then
			item:Disconnect()
		elseif type(item.Cancel) == "function" then
			item:Cancel()
		else
			Util.Warn("Cleanup: tabla sin Destroy/Disconnect/Cancel; no se pudo liberar")
		end
	else
		Util.Warn("Cleanup: tipo no soportado:", kind)
	end
end

function Cleanup.new()
	local self = setmetatable({}, Cleanup)
	self._items = {}
	self._destroyed = false
	self._parent = nil
	return self
end

-- Registra un elemento. Si el ámbito ya fue destruido, el elemento se libera de inmediato.
function Cleanup:Add(item)
	if item == nil then
		Util.Error("Cleanup:Add recibió nil", 2)
	end
	if self._destroyed then
		Util.SafeCall("liberación tardía", dispose, item)
		return item
	end
	table.insert(self._items, item)
	return item
end

-- Quita un elemento SIN liberarlo. Devuelve true si estaba registrado.
function Cleanup:Remove(item)
	for index = #self._items, 1, -1 do
		if self._items[index] == item then
			table.remove(self._items, index)
			return true
		end
	end
	return false
end

-- Quita un elemento y lo libera. Devuelve true si estaba registrado.
function Cleanup:Dispose(item)
	if self:Remove(item) then
		Util.SafeCall("liberación", dispose, item)
		return true
	end
	return false
end

-- Crea un ámbito hijo que se destruye junto con este.
function Cleanup:Child()
	local child = Cleanup.new()
	child._parent = self
	self:Add(child)
	return child
end

function Cleanup:IsDestroyed()
	return self._destroyed
end

function Cleanup:Count()
	return #self._items
end

function Cleanup:Destroy()
	if self._destroyed then
		return
	end
	self._destroyed = true
	local items = self._items
	self._items = {}
	if self._parent then
		self._parent:Remove(self)
		self._parent = nil
	end
	for index = #items, 1, -1 do
		Util.SafeCall("liberación", dispose, items[index])
	end
end

return Cleanup
