--[[
	Pruebas de la Fase 1 — LocalScript en StarterPlayer > StarterPlayerScripts (modo Play).
	Imprime PASS/FAIL por cada comprobación y un resumen. Algunos FAIL esperados NO existen:
	los avisos "[xNUU7Hub] ..." que aparecen en la salida son los de las pruebas de error.
	Este script destruye la librería al final; no lo dejes junto al demo.
]]

local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")

local xNUU7 = require(ReplicatedStorage:WaitForChild("xNUU7Hub"))
local playerGui = Players.LocalPlayer:WaitForChild("PlayerGui")

local passed, failed = 0, 0

local function check(name, condition, detail)
	if condition then
		passed = passed + 1
		print("PASS", name)
	else
		failed = failed + 1
		warn("FAIL", name, detail or "")
	end
end

local function contains(list, value)
	return table.find(list, value) ~= nil
end

local function countFrames(parent)
	local count = 0
	for _, child in ipairs(parent:GetChildren()) do
		if child:IsA("Frame") then
			count = count + 1
		end
	end
	return count
end

-- 1. Carga y runtime -----------------------------------------------------------
check("Version es string", type(xNUU7.Version) == "string")
local rt = xNUU7:_GetRuntime()
local gui = rt.Gui
check("ScreenGui creado en PlayerGui", gui.Parent == playerGui)
check("Responsive tiene conexiones activas", rt.Responsive._connections:Count() > 0)

-- 2. Componentes no implementados fallan con mensaje claro -----------------------
local okWindow = pcall(function()
	return xNUU7.CreateWindow
end)
check("CreateWindow aún no existe (error explícito)", not okWindow)

-- 3. Temas ---------------------------------------------------------------------
local themes = xNUU7:ListThemes()
for _, name in ipairs({ "Dark", "Light", "Midnight", "OLED", "Custom" }) do
	check("Tema presente: " .. name, contains(themes, name))
	check("SetTheme('" .. name .. "') devuelve true", xNUU7:SetTheme(name) == true)
	check("GetTheme == " .. name, xNUU7:GetTheme() == name)
end
check("SetTheme con nombre inexistente devuelve false", xNUU7:SetTheme("NoExiste") == false)
local red = Color3.fromRGB(255, 0, 0)
check("SetTheme(tabla) devuelve true", xNUU7:SetTheme({ Accent = red }) == true)
check("Tema Custom activo tras SetTheme(tabla)", xNUU7:GetTheme() == "Custom")
check("Token Accent actualizado", rt.Theme:Get("Accent") == red)

-- 4. Enlace de tema en caliente --------------------------------------------------
local probe = Instance.new("Frame")
probe.Parent = gui
xNUU7:BindTheme(probe, { BackgroundColor3 = "Surface" })
xNUU7:SetTheme("Light")
xNUU7:Configure({ Animations = false })
xNUU7:SetTheme("OLED")
task.wait()
check("Bind sigue al tema (OLED, sin animación)", probe.BackgroundColor3 == rt.Theme:Get("Surface"))
xNUU7:Configure({ Animations = true })
probe:Destroy()

-- 5. Iconos ----------------------------------------------------------------------
local sample = { "house", "settings", "search", "user", "shield", "zap", "code", "palette", "bell", "chevron-down" }
local host = Instance.new("Frame")
host.Parent = gui
for _, name in ipairs(sample) do
	check("HasIcon('" .. name .. "')", xNUU7:HasIcon(name))
	local icon = xNUU7:CreateIcon(name, { Size = 24, Parent = host })
	check("CreateIcon('" .. name .. "') crea partes", #icon.Instance:GetChildren() > 0)
end
local missing = xNUU7:CreateIcon("no-existe-xyz", { Size = 24, Parent = host })
check("Icono inexistente -> fallback (Frame)", missing.Instance:IsA("Frame") and #missing.Instance:GetChildren() > 0)

local custom = Color3.fromRGB(10, 20, 30)
local colored = xNUU7:CreateIcon("x", { Color = custom, Parent = host })
local fillFound = false
for _, part in ipairs(colored.Instance:GetChildren()) do
	if part:GetAttribute("IconFill") and part.BackgroundColor3 == custom then
		fillFound = true
	end
end
check("Icon con Color3 fijo se pinta", fillFound)

xNUU7:RegisterGlyph("test-glyph", "*")
check("RegisterGlyph + HasIcon", xNUU7:HasIcon("test-glyph"))
local badAsset = pcall(function()
	xNUU7:RegisterAsset("bad", "https://example.com/x.png")
end)
check("RegisterAsset rechaza URLs", not badAsset)
host:Destroy()

-- 6. Validación de Notify --------------------------------------------------------
check("Notify rechaza Title no-string", not pcall(function()
	xNUU7:Notify({ Title = 123 })
end))
check("Notify rechaza Type inválido", not pcall(function()
	xNUU7:Notify({ Title = "x", Type = "Nope" })
end))
check("Notify rechaza argumento no-tabla", not pcall(function()
	xNUU7:Notify("hola")
end))

-- 7. Notificaciones: ciclo de vida -----------------------------------------------
local holder = rt.Notifications._holder
local handles = {}
for _, kind in ipairs({ "Info", "Success", "Warning", "Error" }) do
	table.insert(handles, xNUU7:Notify({ Title = kind, Type = kind, Duration = 0.3 }))
end
task.wait(0.1)
check("4 notificaciones visibles", countFrames(holder) == 4, tostring(countFrames(holder)))
task.wait(1.6)
check("Se destruyen solas tras Duration", countFrames(holder) == 0, tostring(countFrames(holder)))
check("IsClosed true tras cerrarse", handles[1].IsClosed())

rt.Notifications.MaxVisible = 2
for index = 1, 4 do
	xNUU7:Notify({ Title = "Fija " .. index, Duration = 0 })
end
check("MaxVisible limita las activas", #rt.Notifications._active == 2, tostring(#rt.Notifications._active))
rt.Notifications:CloseAll()
task.wait(1)
check("CloseAll vacía la pila", countFrames(holder) == 0, tostring(countFrames(holder)))
rt.Notifications.MaxVisible = 5

-- 8. Destrucción y limpieza ------------------------------------------------------
xNUU7:Notify({ Title = "Pendiente", Duration = 0 })
local connections = rt.Responsive._connections
xNUU7:Destroy()
check("ScreenGui destruido", gui.Parent == nil)
check("Cleanup raíz destruido", rt.Cleanup:IsDestroyed())
check("Sin conexiones vivas en Responsive", connections:Count() == 0, tostring(connections:Count()))

-- 9. Reinicialización tras Destroy -----------------------------------------------
local okRestart = pcall(function()
	xNUU7:Notify({ Title = "Reinicio", Duration = 0.2 })
end)
check("La librería se reinicia tras Destroy", okRestart)
local rt2 = xNUU7:_GetRuntime()
check("Nuevo runtime distinto del anterior", rt2 ~= rt and rt2.Gui ~= gui)
xNUU7:Destroy()
check("Segundo Destroy limpio", rt2.Cleanup:IsDestroyed())

print(string.format("== Fase 1: %d PASS, %d FAIL ==", passed, failed))
