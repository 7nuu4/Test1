# xNUU7 HUB — Fase 1 de 4

Librería de interfaz para Roblox (Luau, cliente). Identidad visual propia (oscura, minimalista, inspirada en Apple), sin dependencias de ejecutores, sin objetos remotos de otros juegos y sin assets de terceros.

**Estado:** Fase 1 entregada = infraestructura completa + notificaciones. Ventanas, pestañas y componentes **todavía no existen** (ver [Hoja de ruta](#hoja-de-ruta)). Nada de lo entregado se ha ejecutado en Roblox Studio (ver [Pruebas](#pruebas)).

---

## 1. Análisis de la referencia (qué se leyó y qué no)

Fuente leída: `windui.lua` del repositorio `caomod2077/Script` (copia modificada de WindUI **v1.6.65**, autor Footagesus, licencia **MIT** según su cabecera). El repositorio oficial `Footagesus/WindUI` **no se consultó**.

**Limitación importante:** la descarga se cortó en mitad del elemento `Button`. Es un archivo compilado/minificado (nombres de variables de una letra), lo que dificulta leer la API por nombres. **No se han leído:** `Window`, `Tab`, `Section`, `Toggle`, `Slider`, `Keybind`, `Colorpicker`, `Dropdown` (como elemento), `Code`, `Divider`, ni el resto del archivo. No afirmo nada sobre su comportamiento. Antes de la Fase 2 hará falta releer esas secciones (o aportar el archivo completo).

**Sí leído (módulos internos):** formas "squircle" por imágenes con 9-slice, gestor de iconos, tabla de temas y fallbacks, utilidades (`Creator`), localización, notificaciones, servicios de claves (key system), diálogo/popup, 18 temas con nombre (Obsidian, Dark, Light, Rose, Plant, Red, Indigo, Sky, Violet, Amber, Emerald, Midnight, Crimson, MonokaiPro, CottonCandy, Mellowsi, Rainbow, BigFroot), entrada de texto, scrollbar, `Tag`, `ConfigManager` (guardar/cargar JSON), botón de apertura, tooltip, acrílico/desenfoque, elemento base, `Paragraph` y el inicio de `Button`.

**API observada en lo leído:** `Notify{Title, Content, Icon, IconThemed, Background, Duration, Buttons, CanClose, Progress}`; diálogo `{Title, Content, Icon, Thumbnail, Buttons{Title, Icon, Callback, Variant}}`; elementos con `Title, Desc, Icon, Color, Justify, Locked, Callback, Tags`; métodos `SetTitle/SetDesc/Lock/Unlock/Highlight/Destroy`; `SetTheme`, `AddIcons`, `SetIconsType`.

## 2. Dependencias de la referencia

| Dependencia | Clasificación | Observaciones |
|---|---|---|
| `ReplicatedStorage:GetIcons` | **Específica del entorno original** | Se usa `WaitForChild("GetIcons", 99999):InvokeServer()`; por `InvokeServer` debe ser un `RemoteFunction` del juego, y el resultado se usa como tabla `Icons[paquete].Icons[nombre] = {Image, ImageRectSize, ImageRectPosition, Parts}`. Se emplea en Studio o cuando no hay `writefile`. Si no existe, la carga queda esperando ~99999 s. **No se reproduce.** |
| `raw.githubusercontent.com/Footagesus/Icons/main/Main-v2.lua` (vía `loadstring`) | **Externa** | Catálogo "lucide" descargado por HTTP. Requiere `loadstring` y HTTP. **No se usa.** |
| Imágenes `rbxassetid://…` (formas squircle, sombra, ruido acrílico, flecha de tooltip) y fuente `rbxassetid://12187365364` | **Externa (terceros)** | Propiedad y accesibilidad **no verificadas**. **No se usan.** |
| `cloneref`, `writefile/readfile/isfile/makefolder/listfiles/delfile`, `getcustomasset`, `request/http_request/syn.request`, `setclipboard`, `gethwid`, `identifyexecutor`, `loadstring` | **Específicas de ejecutor** | No existen en un proyecto normal de Studio. **No se usan.** |
| Key system: Platoboost (`api.platoboost.app/.net`), Pandauth (`api.pandauth.com`), Luarmor (`sdkapi-public.luarmor.net`), `JunkieProtected` | **Externas** | Servicios de licencias de terceros; fuera del alcance. |
| `TweenService`, `UserInputService`, `RunService`, `HttpService`, `LocalizationService`, `Workspace.CurrentCamera`, `Lighting` (`DepthOfFieldEffect`) | **Oficial de Roblox** | El acrílico de la referencia modifica los `DepthOfFieldEffect` de `Lighting` (los desactiva); xNUU7 no hace eso. |

## 3. Licencias y atribuciones

* WindUI (Footagesus) es MIT. **Este código no copia código de WindUI**: es una implementación independiente que toma la organización funcional como referencia. Aun así se reconoce la inspiración: *WindUI © Footagesus, MIT, https://github.com/Footagesus/WindUI*.
* Si en fases posteriores se reutilizara código de WindUI, se conservará su aviso de copyright y el texto de la licencia MIT.
* Iconos integrados: dibujados por este proyecto con Frames. No hay imágenes ni librerías de iconos externas.
* Paleta de temas: valores propios, inspirados en convenciones de color de Apple; no se usan assets de Apple.

## 4. Estructura

```
xnuu7/
├─ src/xNUU7Hub/            ← ModuleScript "xNUU7Hub" (init.lua) con sus hijos
│  ├─ init.lua              Core: API pública y runtime
│  ├─ Util.lua              Registro, validación, fábrica de instancias
│  ├─ CleanupManager.lua    Ámbitos de limpieza
│  ├─ ConnectionManager.lua Conexiones con errores registrados y sin duplicados
│  ├─ AnimationManager.lua  TweenService con cancelación y velocidad global
│  ├─ ThemeManager.lua      Tokens, 5 temas, enlace en caliente
│  ├─ IconManager.lua       Catálogo propio, fallback, caché
│  ├─ ResponsiveManager.lua Viewport, dispositivo, Fit, listeners
│  └─ NotificationManager.lua
├─ examples/Phase1Demo.client.lua
├─ tests/Phase1.client.lua
└─ README.md
```

## 5. Instalación en Roblox Studio

**Con Rojo:** apunta una carpeta de `ReplicatedStorage` a `src/` (el `init.lua` crea el ModuleScript `xNUU7Hub` con sus hijos).

**A mano:**
1. En `ReplicatedStorage` crea un **ModuleScript** llamado `xNUU7Hub` y pega `init.lua`.
2. Dentro de él crea un ModuleScript hijo por cada archivo, con **exactamente** estos nombres: `Util`, `CleanupManager`, `ConnectionManager`, `AnimationManager`, `ThemeManager`, `IconManager`, `ResponsiveManager`, `NotificationManager`.
3. Pega el demo en un **LocalScript** en `StarterPlayer > StarterPlayerScripts` y entra en Play.

```lua
local xNUU7 = require(game:GetService("ReplicatedStorage"):WaitForChild("xNUU7Hub"))
xNUU7:Notify({ Title = "xNUU7 HUB", Content = "Funciona.", Type = "Success" })
```

## 6. API de la Fase 1

| Método | Descripción |
|---|---|
| `Notify(opts)` | `Title` (string), `Content` (string), `Duration` (s, defecto 4; `0` = fija), `Type` (`Info`/`Success`/`Warning`/`Error`), `Icon` (nombre). Devuelve `{Close(), IsClosed()}`. Un toque sobre la tarjeta la cierra. Parámetros inválidos lanzan error. |
| `SetTheme(nombre \| tabla)` | `Dark`, `Light`, `Midnight`, `OLED`, `Custom`, o una tabla de tokens (se aplica como `Custom`). Devuelve `false` con aviso si el nombre no existe. |
| `GetTheme()` / `ListThemes()` / `RegisterTheme(nombre, tabla)` | Consulta y registro de temas propios (no se pueden sobrescribir los integrados). |
| `BindTheme(instancia, {Propiedad = "Token" \| función(theme)}, scope?)` | Enlaza propiedades al tema activo; devuelve la función para desenlazar. |
| `CreateIcon(nombre, opts)` | `Size` (número o UDim2, defecto 20), `Color` (Color3 o token, defecto `"Text"`), `Thickness` (0.04–0.3), `Parent`. Devuelve `{Instance, SetColor, SetSize, Destroy}`. Nombre inexistente → icono de reserva y un solo aviso. |
| `RegisterAsset(nombre, id, rectSize?, rectOffset?)` / `RegisterGlyph(nombre, texto)` / `RegisterIcon(nombre, def)` | Amplía el catálogo con **tus** assets o glifos. |
| `HasIcon` / `ListIcons` | Consulta del catálogo. |
| `Configure{Animations, AnimationSpeed, ThemeTransition, Parent}` | Ajustes globales; se aplican también en caliente. |
| `Destroy()` | Libera ScreenGui, conexiones, tweens y observadores. La librería puede reiniciarse después. |

**Tokens de tema:** `Background, Surface, SurfaceHover, SurfaceActive, Border, Text, TextSecondary, Accent, AccentText, Success, Warning, Danger, Shadow` (Color3) y `PanelTransparency, BorderTransparency, CornerRadius, ElementRadius` (número, con límites).

**Iconos integrados:** `x, minus, plus, check, chevron-down, chevron-up, chevron-left, chevron-right, menu, search, house, settings, user, shield, zap, code, palette, bell, info, alert, fallback`. (`settings` es un panel de deslizadores, no un engranaje.)

## 7. Pruebas

**Verificado por inspección estática (releyendo el código):** dependencias entre módulos sin ciclos; ningún `pcall` silencioso (los fallos pasan por `Util.SafeCall` con traza); todas las conexiones pasan por `ConnectionManager` o por un `Cleanup`; los tweens son por propiedad y se cancelan al destruir; no hay bucles `while`/`Heartbeat` permanentes; ningún acceso a `ReplicatedStorage`, `loadstring`, HTTP ni funciones de ejecutor.

**No verificado (pendiente de ejecución en Studio):** **todo el comportamiento en tiempo de ejecución.** No había Luau ni Studio disponibles, así que **ni siquiera se comprobó la sintaxis con un compilador**. Es posible que haya errores. Para comprobarlo, ejecuta `tests/Phase1.client.lua` (≈50 comprobaciones: temas, iconos, fallback, validación, ciclo de vida de notificaciones, límite `MaxVisible`, destrucción, conexiones vivas, reinicio) y revisa visualmente el demo. Puntos que más dudo: el aspecto del borde alrededor del `CanvasGroup` de las notificaciones, la forma de los iconos dibujados (tamaños pequeños) y el comportamiento de `ScreenInsets` en dispositivos con notch.

## 8. Limitaciones conocidas

* No hay ventanas, pestañas, componentes, `Dialog` ni búsqueda (Fases 2–4).
* Solo cliente; requiere `LocalPlayer` y `PlayerGui`.
* Los iconos integrados son 21; para más, registra tus assets (`RegisterAsset`) o glifos. Los glifos dependen de la fuente.
* Las notificaciones no se pausan al mantener el puntero encima.
* Sin localización ni guardado de configuración (la referencia depende del sistema de archivos del ejecutor; se estudiará una alternativa con `DataStore`/atributos en fases posteriores).
* La clasificación Phone/Tablet/Desktop es una heurística.

## Hoja de ruta

| Fase | Contenido |
|---|---|
| 1 ✅ | Core, Cleanup, Connection, Animation, Theme, Icon, Responsive, Notification |
| 2 | WindowManager, TabManager: ventana, arrastre, minimizar/cerrar, pestañas, scroll, responsive |
| 3 | ComponentFactory: Section, Button, Toggle, Checkbox, Slider, Input, Dropdown, Keybind, Paragraph, Label, Divider, Code |
| 4 | Colorpicker, DialogManager, SearchManager, InputManager, documentación final y pruebas completas |
