--[[
	Demo de la Fase 1 — LocalScript en StarterPlayer > StarterPlayerScripts.
	Requiere que el ModuleScript "xNUU7Hub" esté en ReplicatedStorage.
	Muestra: notificaciones de los 4 estilos, cambio de tema en caliente y la galería de iconos.
]]

local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")

local xNUU7 = require(ReplicatedStorage:WaitForChild("xNUU7Hub"))

local playerGui = Players.LocalPlayer:WaitForChild("PlayerGui")

-- 1) Galería de iconos (usa los iconos integrados, ninguno depende de assets externos).
local gallery = Instance.new("ScreenGui")
gallery.Name = "xNUU7Gallery"
gallery.ResetOnSpawn = false
gallery.Parent = playerGui

local panel = Instance.new("Frame")
panel.AnchorPoint = Vector2.new(0.5, 1)
panel.Position = UDim2.new(0.5, 0, 1, -16)
panel.Size = UDim2.fromOffset(340, 0)
panel.AutomaticSize = Enum.AutomaticSize.Y
panel.BorderSizePixel = 0
panel.Parent = gallery

local corner = Instance.new("UICorner")
corner.Parent = panel
local padding = Instance.new("UIPadding")
padding.PaddingTop = UDim.new(0, 12)
padding.PaddingBottom = UDim.new(0, 12)
padding.PaddingLeft = UDim.new(0, 12)
padding.PaddingRight = UDim.new(0, 12)
padding.Parent = panel
local grid = Instance.new("UIGridLayout")
grid.CellSize = UDim2.fromOffset(44, 44)
grid.CellPadding = UDim2.fromOffset(8, 8)
grid.Parent = panel

-- El panel sigue al tema activo sin que el demo guarde ningún color.
xNUU7:BindTheme(panel, { BackgroundColor3 = "Surface" })
xNUU7:BindTheme(corner, { CornerRadius = function(theme)
	return UDim.new(0, theme.CornerRadius)
end })

for _, name in ipairs(xNUU7:ListIcons()) do
	local cell = Instance.new("Frame")
	cell.BackgroundTransparency = 1
	cell.Parent = panel
	local icon = xNUU7:CreateIcon(name, { Size = 26, Color = "Text" })
	icon.Instance.AnchorPoint = Vector2.new(0.5, 0.5)
	icon.Instance.Position = UDim2.fromScale(0.5, 0.5)
	icon.Instance.Parent = cell
end

-- 2) Notificaciones de los cuatro estilos.
xNUU7:Notify({ Title = "xNUU7 HUB", Content = "Fase 1: infraestructura lista.", Type = "Info" })
task.wait(0.4)
xNUU7:Notify({ Title = "Guardado", Content = "Los cambios se aplicaron.", Type = "Success" })
task.wait(0.4)
xNUU7:Notify({ Title = "Atención", Content = "Esta notificación usa un icono propio.", Type = "Warning", Icon = "bell" })
task.wait(0.4)
xNUU7:Notify({ Title = "Error", Content = "Toca la tarjeta para cerrarla.", Type = "Error", Duration = 6 })

-- 3) Recorrido por los temas (una sola vez).
task.wait(1.5)
for _, themeName in ipairs({ "Light", "Midnight", "OLED", "Dark" }) do
	xNUU7:SetTheme(themeName)
	xNUU7:Notify({ Title = "Tema: " .. themeName, Duration = 1.6, Icon = "palette" })
	task.wait(1.8)
end

-- 4) Tema personalizado a partir de una tabla de tokens.
xNUU7:SetTheme({ Accent = Color3.fromRGB(255, 94, 160), CornerRadius = 24 })
xNUU7:Notify({ Title = "Tema Custom", Content = "Acento y radio personalizados.", Duration = 3 })

-- Para liberar todo: xNUU7:Destroy() y gallery:Destroy()
